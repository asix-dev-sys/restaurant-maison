import React, { useState } from "react";
import "./Header.css";
import { FiShoppingBag } from "react-icons/fi";
import card4 from "../assets/img/Снимок экрана 2026-10-31 103813.png";
import Backet from "../Backet/Backet";

const Header = ({
  cartItems = [],
  onBooking,
  onCheckout,
  changeQuantity,
  removeFromCart,
}) => {
  const [isOpen, setIsOpen] = useState(false);

  const cartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <>
      <header className="navbar">
        <div className="logo">
          <img src={card4} alt="Логотип ресторана" />
        </div>

        <nav className="nav-links">
          <a href="#">Главная</a>
          <a href="#" className="active">
            Меню
          </a>
          <a href="#">О ресторане</a>
          <a href="#">Контакты</a>
        </nav>

        <div className="nav-actions">
          <div className="bag-icon" onClick={() => setIsOpen(true)}>
            <FiShoppingBag />
          </div>

          <button className="nr" onClick={onBooking}>
            Забронировать <span>↗</span>
          </button>
        </div>
      </header>

      <Backet
        isOpen={isOpen}
        setIsOpen={setIsOpen}
        cartItems={cartItems}
        onCheckout={() => {
          setIsOpen(false);
          onCheckout();
        }}
        changeQuantity={changeQuantity}
        removeFromCart={removeFromCart}
      />
    </>
  );
};

export default Header;
